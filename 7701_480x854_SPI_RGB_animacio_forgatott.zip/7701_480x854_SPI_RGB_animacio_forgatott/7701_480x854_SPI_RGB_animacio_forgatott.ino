/**
 * | Supported ESP SoCs | ESP32-S3 |
 * | ------------------ | -------- |
 *
 * | Supported LCD Controllers | GC9503 | ST7701 |
 * | ------------------------- | ------ | ------ |
 *
 * # 3-wire SPI + RGB LCD Example
 *
 * The example demonstrates how to develop different model LCDs with "3-wire SPI + RGB" interface using standalone drivers and test them by displaying color bars.
 *
 * ## How to use
 *
 * 1. [Configure drivers](https://github.com/esp-arduino-libs/ESP32_Display_Panel#configuring-drivers) if needed.
 * 2. Modify the macros in the example to match the parameters according to your hardware.
 * 3. Navigate to the `Tools` menu in the Arduino IDE to choose a ESP board and configure its parameters, please refter to [Configuring Supported Development Boards](https://github.com/esp-arduino-libs/ESP32_Display_Panel#configuring-supported-development-boards)
 * 4. Verify and upload the example to your ESP board.
 *
 * ## Serial Output
 *
 * ```
 * ...
 * 3-wire SPI + RGB LCD example start
 * Initialize backlight and turn it off
 * Create 3-wire SPI + RGB LCD bus
 * Create LCD device
 * Draw color bar from top left to bottom right, the order is B - G - R
 * Turn on the backlight
 * 3-wire SPI + RGB LCD example end
 * RGB refresh rate: 0
 * RGB refresh rate: 60
 * RGB refresh rate: 60
 * RGB refresh rate: 60
 * ...
 * ```
 *
 * ## Troubleshooting
 *
 * Please check the [FAQ](https://github.com/esp-arduino-libs/ESP32_Display_Panel#faq) first to see if the same question exists. If not, please create a [Github issue](https://github.com/esp-arduino-libs/ESP32_Display_Panel/issues). We will get back to you as soon as possible.
 *
 */

#include <Arduino.h>
#include <ESP_Panel_Library.h>
#include "lv_conf.h"
#include <lvgl.h>
#include <math.h>
#include <freertos/FreeRTOS.h>
#include <freertos/semphr.h>

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////// Please update the following configuration according to your LCD spec //////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/**
 * Currently, the library supports the following "3-wire SPI + RGB" LCDs:
 *      - GC9503
 *      - ST7701
 */
#define EXAMPLE_LCD_NAME                    ST7701
#define EXAMPLE_LCD_WIDTH                   (480)
#define EXAMPLE_LCD_HEIGHT                  (854)
                                                    // | 8-bit RGB888 | 16-bit RGB565 |
#define EXAMPLE_LCD_COLOR_BITS              (16)    // |      24      |   16/18/24    |
#define EXAMPLE_LCD_RGB_DATA_WIDTH          (16)    // |      8       |      16       |
#define EXAMPLE_LCD_RGB_TIMING_FREQ_HZ      (15 * 1000 * 1000)
#define EXAMPLE_LCD_RGB_TIMING_HPW          8//(10)
#define EXAMPLE_LCD_RGB_TIMING_HBP          20//(10)
#define EXAMPLE_LCD_RGB_TIMING_HFP          20//(20)
#define EXAMPLE_LCD_RGB_TIMING_VPW          4//(10)
#define EXAMPLE_LCD_RGB_TIMING_VBP          16//(10)
#define EXAMPLE_LCD_RGB_TIMING_VFP          16//(10)
#define EXAMPLE_LCD_USE_EXTERNAL_CMD        (1)
#if EXAMPLE_LCD_USE_EXTERNAL_CMD
/**
 * LCD initialization commands.
 *
 * Vendor specific initialization can be different between manufacturers, should consult the LCD supplier for
 * initialization sequence code.
 *
 * Please uncomment and change the following macro definitions, then use `configVendorCommands()` to pass them in the
 * same format if needed. Otherwise, the LCD driver will use the default initialization sequence code.
 *
 * There are two formats for the sequence code:
 *   1. Raw data: {command, (uint8_t []){ data0, data1, ... }, data_size, delay_ms}
 *   2. Formater: ESP_PANEL_LCD_CMD_WITH_8BIT_PARAM(delay_ms, command, { data0, data1, ... }) and
 *                ESP_PANEL_LCD_CMD_WITH_NONE_PARAM(delay_ms, command)
 */
//const esp_lcd_panel_vendor_init_cmd_t lcd_init_cmd[] = {
    // {0xFF, (uint8_t []){0x77, 0x01, 0x00, 0x00, 0x10}, 5, 0},
    // {0xC0, (uint8_t []){0x3B, 0x00}, 2, 0},
    // {0xC1, (uint8_t []){0x0D, 0x02}, 2, 0},
    // {0x29, (uint8_t []){0x00}, 0, 120},
    // // or
    // ESP_PANEL_LCD_CMD_WITH_8BIT_PARAM(0, 0xFF, {0x77, 0x01, 0x00, 0x00, 0x10}),
    // ESP_PANEL_LCD_CMD_WITH_8BIT_PARAM(0, 0xC0, {0x3B, 0x00}),
    // ESP_PANEL_LCD_CMD_WITH_8BIT_PARAM(0, 0xC1, {0x0D, 0x02}),
    // ESP_PANEL_LCD_CMD_WITH_NONE_PARAM(120, 0x29),
//};
const esp_lcd_panel_vendor_init_cmd_t lcd_init_cmd[] = {
    ESP_PANEL_LCD_CMD_WITH_8BIT_PARAM(0, 0xFF, {0x77, 0x01, 0x00, 0x00, 0x10}),
    ESP_PANEL_LCD_CMD_WITH_8BIT_PARAM(0, 0xC0, {0x69, 0x02}), // 854 sor (105+1)*8 + 6
    ESP_PANEL_LCD_CMD_WITH_8BIT_PARAM(0, 0xC1, {0x0D, 0x02}),
    ESP_PANEL_LCD_CMD_WITH_8BIT_PARAM(0, 0xC2, {0x31, 0x05}),   //05
    ESP_PANEL_LCD_CMD_WITH_8BIT_PARAM(0, 0xCC, {0x10}),
    ESP_PANEL_LCD_CMD_WITH_8BIT_PARAM(0, 0xB0, {0x00, 0x0E, 0x15, 0x0F, 0x11, 0x08, 0x08, 0x08, 0x08, 0x23, 0x04, 0x13, 0x12, 0x2B, 0x34, 0x1F}),
    ESP_PANEL_LCD_CMD_WITH_8BIT_PARAM(0, 0xB1, {0x00, 0x0E, 0x95, 0x0F, 0x13, 0x07, 0x09, 0x08, 0x08, 0x22, 0x04, 0x10, 0x0E, 0x2C, 0x34, 0x1F}),
    ESP_PANEL_LCD_CMD_WITH_8BIT_PARAM(0, 0xFF, {0x77, 0x01, 0x00, 0x00, 0x11}),
    ESP_PANEL_LCD_CMD_WITH_8BIT_PARAM(0, 0xB0, {0x30}), //0x4D
    ESP_PANEL_LCD_CMD_WITH_8BIT_PARAM(0, 0xB1, {0x20}), //0x35
    ESP_PANEL_LCD_CMD_WITH_8BIT_PARAM(0, 0xB2, {0x07}),
    ESP_PANEL_LCD_CMD_WITH_8BIT_PARAM(0, 0xB3, {0x80}),
    ESP_PANEL_LCD_CMD_WITH_8BIT_PARAM(0, 0xB5, {0x47}),
    ESP_PANEL_LCD_CMD_WITH_8BIT_PARAM(0, 0xB7, {0x85}), //0x8A
    ESP_PANEL_LCD_CMD_WITH_8BIT_PARAM(0, 0xB8, {0x21}),
    ESP_PANEL_LCD_CMD_WITH_8BIT_PARAM(0, 0xC1, {0x78}),
    ESP_PANEL_LCD_CMD_WITH_8BIT_PARAM(0, 0xC2, {0x78}),
    ESP_PANEL_LCD_CMD_WITH_8BIT_PARAM(100, 0xD0, {0x88}),
    ESP_PANEL_LCD_CMD_WITH_8BIT_PARAM(0, 0xE0, {0x00, 0x00, 0x02}),
    ESP_PANEL_LCD_CMD_WITH_8BIT_PARAM(0, 0xE1, {0x04, 0x00, 0x00, 0x00, 0x05, 0x00, 0x00, 0x00, 0x00, 0x20, 0x20}),
    ESP_PANEL_LCD_CMD_WITH_8BIT_PARAM(0, 0xE2, {0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00}),
    ESP_PANEL_LCD_CMD_WITH_8BIT_PARAM(0, 0xE3, {0x00, 0x00, 0x33, 0x00}),
    ESP_PANEL_LCD_CMD_WITH_8BIT_PARAM(0, 0xE4, {0x22, 0x00}),
    ESP_PANEL_LCD_CMD_WITH_8BIT_PARAM(0, 0xE5, {0x04, 0x34, 0xAA, 0xAA, 0x06, 0x34, 0xAA, 0xAA, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00}),
    ESP_PANEL_LCD_CMD_WITH_8BIT_PARAM(0, 0xE6, {0x00, 0x00, 0x33, 0x00}),
    ESP_PANEL_LCD_CMD_WITH_8BIT_PARAM(0, 0xE7, {0x22, 0x00}),
    ESP_PANEL_LCD_CMD_WITH_8BIT_PARAM(0, 0xE8, {0x05, 0x34, 0xAA, 0xAA, 0x07, 0x34, 0xAA, 0xAA, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00}),
    ESP_PANEL_LCD_CMD_WITH_8BIT_PARAM(0, 0xEB, {0x02, 0x00, 0x40, 0x40, 0x00, 0x00, 0x00}),
    ESP_PANEL_LCD_CMD_WITH_8BIT_PARAM(0, 0xEC, {0x00, 0x00}),
    ESP_PANEL_LCD_CMD_WITH_8BIT_PARAM(0, 0xED, {0xFA, 0x45, 0x0B, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xB0, 0x54, 0xAF}),
    ESP_PANEL_LCD_CMD_WITH_8BIT_PARAM(0, 0xFF, {0x77, 0x01, 0x00, 0x00, 0x00}),
    ESP_PANEL_LCD_CMD_WITH_8BIT_PARAM(0, 0x3A, {0x55}),
    ESP_PANEL_LCD_CMD_WITH_NONE_PARAM(120, 0x11),
    ESP_PANEL_LCD_CMD_WITH_NONE_PARAM(20, 0x29),
    //ESP_PANEL_LCD_CMD_WITH_NONE_PARAM(20, 0x23),
};
#endif

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////// Please update the following configuration according to your board spec ////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#define EXAMPLE_LCD_PIN_NUM_RGB_DISP            (-1)
#define EXAMPLE_LCD_PIN_NUM_RGB_VSYNC           (47)
#define EXAMPLE_LCD_PIN_NUM_RGB_HSYNC           (4)
#define EXAMPLE_LCD_PIN_NUM_RGB_DE              (5)
#define EXAMPLE_LCD_PIN_NUM_RGB_PCLK            (42)
                                                        // | RGB565 | RGB666 | RGB888 |
                                                        // |--------|--------|--------|
#define EXAMPLE_LCD_PIN_NUM_RGB_DATA0           (18)     // |   B0   |  B0-1  |   B0-3 |
#define EXAMPLE_LCD_PIN_NUM_RGB_DATA1           (21)     // |   B1   |  B2    |   B4   |
#define EXAMPLE_LCD_PIN_NUM_RGB_DATA2           (39)     // |   B2   |  B3    |   B5   |
#define EXAMPLE_LCD_PIN_NUM_RGB_DATA3           (40)     // |   B3   |  B4    |   B6   |
#define EXAMPLE_LCD_PIN_NUM_RGB_DATA4           (41)    // |   B4   |  B5    |   B7   |
#define EXAMPLE_LCD_PIN_NUM_RGB_DATA5           (12)     // |   G0   |  G0    |   G0-2 |
#define EXAMPLE_LCD_PIN_NUM_RGB_DATA6           (13)    // |   G1   |  G1    |   G3   |
#define EXAMPLE_LCD_PIN_NUM_RGB_DATA7           (14)     // |   G2   |  G2    |   G4   |
#if EXAMPLE_LCD_RGB_DATA_WIDTH > 8
#define EXAMPLE_LCD_PIN_NUM_RGB_DATA8           (15)    // |   G3   |  G3    |   G5   |
#define EXAMPLE_LCD_PIN_NUM_RGB_DATA9           (16)     // |   G4   |  G4    |   G6   |
#define EXAMPLE_LCD_PIN_NUM_RGB_DATA10          (17)    // |   G5   |  G5    |   G7   |
#define EXAMPLE_LCD_PIN_NUM_RGB_DATA11          (7)    // |   R0   |  R0-1  |   R0-3 |
#define EXAMPLE_LCD_PIN_NUM_RGB_DATA12          (8)    // |   R1   |  R2    |   R4   |
#define EXAMPLE_LCD_PIN_NUM_RGB_DATA13          (9)    // |   R2   |  R3    |   R5   |
#define EXAMPLE_LCD_PIN_NUM_RGB_DATA14          (10)    // |   R3   |  R4    |   R6   |
#define EXAMPLE_LCD_PIN_NUM_RGB_DATA15          (11)     // |   R4   |  R5    |   R7   |
#endif
#define EXAMPLE_LCD_PIN_NUM_SPI_CS              (3)
#define EXAMPLE_LCD_PIN_NUM_SPI_SCK             (2)
#define EXAMPLE_LCD_PIN_NUM_SPI_SDA             (1)
#define EXAMPLE_LCD_PIN_NUM_RST                 (-1)    // Set to -1 if not used
#define EXAMPLE_LCD_PIN_NUM_BK_LIGHT            (-1)    // Set to -1 if not used
#define EXAMPLE_LCD_BK_LIGHT_ON_LEVEL           (-1)
#define EXAMPLE_LCD_BK_LIGHT_OFF_LEVEL          !EXAMPLE_LCD_BK_LIGHT_ON_LEVEL

/* Enable or disable printing RGB refresh rate */
#define EXAMPLE_ENABLE_PRINT_LCD_FPS            (1)

#define _EXAMPLE_LCD_CLASS(name, ...) ESP_PanelLcd_##name(__VA_ARGS__)
#define EXAMPLE_LCD_CLASS(name, ...)  _EXAMPLE_LCD_CLASS(name, ##__VA_ARGS__)

#if EXAMPLE_ENABLE_PRINT_LCD_FPS

#define EXAMPLE_LCD_FPS_COUNT_MAX               (100)
#endif


ESP_PanelBus_RGB *lcd_bus = nullptr;
ESP_PanelLcd *lcd = nullptr;

// LVGL rajzoló puffer a PSRAM-ban (a képernyő 1/10-e)
static lv_disp_draw_buf_t draw_buf;
static lv_color_t *buf1 = nullptr;

// The only visible element is a single yellow square outline. No filled
// object, ghost trail, background widget or transformed layer is used.
constexpr uint16_t SQUARE_SIZE = 150;
constexpr uint16_t SQUARE_LINE_BOX_SIZE = 250;
constexpr int16_t SQUARE_STEP_ANGLE = 12;   // 1.2 degrees per 80 ms: about 24 seconds per turn

static lv_obj_t *square_line = nullptr;
static lv_point_t square_points[5];
static int16_t square_angle = 0;
static SemaphoreHandle_t vsync_semaphore = nullptr;

// The RGB peripheral calls this from the VSYNC interrupt.  It does no
// drawing: it merely releases loop() so the next LVGL update starts at the
// beginning of a display frame rather than halfway through one.
IRAM_ATTR bool onRgbVsync(void *user_data)
{
    BaseType_t higher_priority_task_woken = pdFALSE;
    SemaphoreHandle_t semaphore = static_cast<SemaphoreHandle_t>(user_data);
    if (semaphore != nullptr) {
        xSemaphoreGiveFromISR(semaphore, &higher_priority_task_woken);
    }
    return higher_priority_task_woken == pdTRUE;
}

void updateSquareOutline(int16_t angle)
{
    // Invalidate the previous outline before changing the shared point array.
    lv_obj_invalidate(square_line);
    while (angle < 0) {
        angle += 3600;
    }
    // angle is in tenths of a degree: radians = angle * pi / 1800.
    const float radians = (angle % 3600) * 0.001745329252F;
    const float sine = sinf(radians);
    const float cosine = cosf(radians);
    const float half_side = SQUARE_SIZE / 2.0F;
    const float centre = SQUARE_LINE_BOX_SIZE / 2.0F;
    const float corners[4][2] = {
        {-half_side, -half_side}, {half_side, -half_side},
        {half_side, half_side}, {-half_side, half_side}
    };

    for (uint8_t point = 0; point < 4; point++) {
        const float x = corners[point][0];
        const float y = corners[point][1];
        square_points[point].x = static_cast<lv_coord_t>(lroundf(centre + (x * cosine) - (y * sine)));
        square_points[point].y = static_cast<lv_coord_t>(lroundf(centre + (x * sine) + (y * cosine)));
    }
    square_points[4] = square_points[0];
    lv_line_set_points(square_line, square_points, 5);

    // Keep the line object's bounding box and its centre constant. This
    // prevents LVGL's content-size refresh from moving the visual centre.
    lv_obj_set_size(square_line, SQUARE_LINE_BOX_SIZE, SQUARE_LINE_BOX_SIZE);
    lv_obj_center(square_line);
}

void configureSquareOutline()
{
    lv_obj_set_size(square_line, SQUARE_LINE_BOX_SIZE, SQUARE_LINE_BOX_SIZE);
    lv_obj_center(square_line);
    lv_obj_clear_flag(square_line, LV_OBJ_FLAG_SCROLLABLE);
    lv_obj_set_style_line_width(square_line, 4, LV_PART_MAIN);
    lv_obj_set_style_line_color(square_line, lv_color_hex(0xFFE000), LV_PART_MAIN);
    lv_obj_set_style_line_opa(square_line, LV_OPA_COVER, LV_PART_MAIN);
    lv_obj_set_style_line_rounded(square_line, false, LV_PART_MAIN);
}

void squareAnimationTimer(lv_timer_t *timer)
{
    (void)timer;
    square_angle = (square_angle + SQUARE_STEP_ANGLE) % 3600;

    updateSquareOutline(square_angle);
}

// Ez a függvény küldi át az LVGL által rajzolt képet a kijelzőre
void my_disp_flush(lv_disp_drv_t *disp, const lv_area_t *area, lv_color_t *color_p) {
    const uint32_t width = area->x2 - area->x1 + 1;
    const uint32_t height = area->y2 - area->y1 + 1;
    lcd->drawBitmapWaitUntilFinish(area->x1, area->y1, width, height, reinterpret_cast<const uint8_t *>(color_p));
    lv_disp_flush_ready(disp);
}

void setup() {
    Serial.begin(115200);
    

    // Kézi hardveres reset a GPIO 6 lábon (ST7701 Active LOW)
    pinMode(6, OUTPUT);
    digitalWrite(6, HIGH);
    delay(20);
    digitalWrite(6, LOW);   // Reset impulzus indítása
    delay(50);
    digitalWrite(6, HIGH);  // Kijelző engedélyezése és stabil HIGH szinten tartása!
    delay(120);             // Várakozás az ST7701 belső indulására

    // 1. Busz és LCD létrehozása
    lcd_bus = new ESP_PanelBus_RGB(
        EXAMPLE_LCD_WIDTH, EXAMPLE_LCD_HEIGHT,
        EXAMPLE_LCD_PIN_NUM_SPI_CS, EXAMPLE_LCD_PIN_NUM_SPI_SCK, EXAMPLE_LCD_PIN_NUM_SPI_SDA,
        EXAMPLE_LCD_PIN_NUM_RGB_DATA0, EXAMPLE_LCD_PIN_NUM_RGB_DATA1, EXAMPLE_LCD_PIN_NUM_RGB_DATA2,
        EXAMPLE_LCD_PIN_NUM_RGB_DATA3, EXAMPLE_LCD_PIN_NUM_RGB_DATA4, EXAMPLE_LCD_PIN_NUM_RGB_DATA5,
        EXAMPLE_LCD_PIN_NUM_RGB_DATA6, EXAMPLE_LCD_PIN_NUM_RGB_DATA7, EXAMPLE_LCD_PIN_NUM_RGB_DATA8,
        EXAMPLE_LCD_PIN_NUM_RGB_DATA9, EXAMPLE_LCD_PIN_NUM_RGB_DATA10, EXAMPLE_LCD_PIN_NUM_RGB_DATA11,
        EXAMPLE_LCD_PIN_NUM_RGB_DATA12, EXAMPLE_LCD_PIN_NUM_RGB_DATA13, EXAMPLE_LCD_PIN_NUM_RGB_DATA14,
        EXAMPLE_LCD_PIN_NUM_RGB_DATA15,
        EXAMPLE_LCD_PIN_NUM_RGB_HSYNC, EXAMPLE_LCD_PIN_NUM_RGB_VSYNC,
        EXAMPLE_LCD_PIN_NUM_RGB_PCLK, EXAMPLE_LCD_PIN_NUM_RGB_DE, EXAMPLE_LCD_PIN_NUM_RGB_DISP
    );
    lcd_bus->configRgbTimingFreqHz(EXAMPLE_LCD_RGB_TIMING_FREQ_HZ);
    lcd_bus->configRgbTimingPorch(
        EXAMPLE_LCD_RGB_TIMING_HPW, EXAMPLE_LCD_RGB_TIMING_HBP, EXAMPLE_LCD_RGB_TIMING_HFP,
        EXAMPLE_LCD_RGB_TIMING_VPW, EXAMPLE_LCD_RGB_TIMING_VBP, EXAMPLE_LCD_RGB_TIMING_VFP
    );
    lcd_bus->begin();

    lcd = new ESP_PanelLcd_ST7701(lcd_bus, EXAMPLE_LCD_COLOR_BITS, EXAMPLE_LCD_PIN_NUM_RST);
    lcd->configVendorCommands(lcd_init_cmd, sizeof(lcd_init_cmd) / sizeof(lcd_init_cmd[0]));
    
    // Helyes inicializálási sorrend (reset az init előtt, vagy elhagyva, mert az init elvégzi)
    //lcd->reset();
    delay(50);
    lcd->init();
    //lcd->reset();
    lcd->begin();
    lcd->displayOn();

    // With a single RGB frame buffer the panel scans it continuously.  Run
    // LVGL immediately after VSYNC so the small changed region is copied
    // before the scan reaches it.  This reduces the risk of visible tearing
    // without adding the large extra frame buffers that previously resulted
    // in a blank screen on this hardware.
    vsync_semaphore = xSemaphoreCreateBinary();
    if (vsync_semaphore == nullptr || !lcd->attachRefreshFinishCallback(onRgbVsync, vsync_semaphore)) {
        Serial.println("Fatal: RGB VSYNC synchronisation setup failed");
        while (true) {
            delay(1000);
        }
    }

    // 2. LVGL inicializálása
    lv_init();
    
    // Small internal-SRAM LVGL buffer; only the central outlines are redrawn.
    size_t buf_size = EXAMPLE_LCD_WIDTH * 40;
    buf1 = static_cast<lv_color_t *>(heap_caps_malloc(buf_size * sizeof(lv_color_t),
                                                       MALLOC_CAP_INTERNAL | MALLOC_CAP_DMA));
    if (buf1 == nullptr) {
        Serial.println("Fatal: LVGL draw-buffer allocation failed");
        while (true) {
            delay(1000);
        }
    }
    lv_disp_draw_buf_init(&draw_buf, buf1, NULL, buf_size);

    static lv_disp_drv_t disp_drv;
    lv_disp_drv_init(&disp_drv);
    disp_drv.hor_res = EXAMPLE_LCD_WIDTH;
    disp_drv.ver_res = EXAMPLE_LCD_HEIGHT;
    // Keep the same visual 270-degree orientation as the working text sketch.
    disp_drv.sw_rotate = 1;
    disp_drv.rotated = LV_DISP_ROT_270;
    disp_drv.flush_cb = my_disp_flush;
    disp_drv.draw_buf = &draw_buf;
    lv_disp_drv_register(&disp_drv);

    // 3. Empty black screen: only the rotating square outlines are visible.
    lv_obj_set_style_bg_color(lv_scr_act(), lv_color_hex(0x000000), LV_PART_MAIN);
    lv_obj_set_style_bg_opa(lv_scr_act(), LV_OPA_COVER, LV_PART_MAIN);

    square_line = lv_line_create(lv_scr_act());
    configureSquareOutline();
    squareAnimationTimer(nullptr);
    lv_timer_create(squareAnimationTimer, 80, nullptr);
}

void loop() {
    // Do not change a live RGB frame in the middle of a scan.  A 25 ms
    // timeout keeps the sketch responsive if a panel is disconnected.
    if (xSemaphoreTake(vsync_semaphore, pdMS_TO_TICKS(25)) == pdTRUE) {
        lv_timer_handler();
    }
}
